
-- Create enum types for the system
CREATE TYPE public.sdg_goal AS ENUM (
  'no_poverty', 'zero_hunger', 'good_health', 'quality_education', 
  'gender_equality', 'clean_water', 'affordable_energy', 'decent_work',
  'industry_innovation', 'reduced_inequalities', 'sustainable_cities',
  'responsible_consumption', 'climate_action', 'life_below_water',
  'life_on_land', 'peace_justice', 'partnerships'
);

CREATE TYPE public.risk_level AS ENUM ('low', 'medium', 'high', 'critical');
CREATE TYPE public.agent_type AS ENUM ('credit_risk', 'portfolio_advisory', 'financial_inclusion');

-- Profiles table for user data
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL UNIQUE,
  full_name TEXT,
  organization TEXT,
  role TEXT,
  avatar_url TEXT,
  preferences JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Portfolios table
CREATE TABLE public.portfolios (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  name TEXT NOT NULL,
  description TEXT,
  total_value DECIMAL(15,2) DEFAULT 0,
  sustainability_score DECIMAL(5,2) DEFAULT 0,
  risk_score DECIMAL(5,2) DEFAULT 0,
  sdg_alignment JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Assets/Investments
CREATE TABLE public.assets (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  portfolio_id UUID REFERENCES public.portfolios(id) ON DELETE CASCADE NOT NULL,
  name TEXT NOT NULL,
  ticker TEXT,
  asset_type TEXT NOT NULL,
  quantity DECIMAL(15,4) DEFAULT 0,
  current_price DECIMAL(15,4) DEFAULT 0,
  purchase_price DECIMAL(15,4) DEFAULT 0,
  esg_score DECIMAL(5,2),
  carbon_footprint DECIMAL(10,2),
  sdg_contributions JSONB DEFAULT '[]',
  metadata JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Risk Assessments
CREATE TABLE public.risk_assessments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  entity_name TEXT NOT NULL,
  entity_type TEXT NOT NULL,
  financial_score DECIMAL(5,2) NOT NULL,
  sustainability_score DECIMAL(5,2) NOT NULL,
  overall_risk risk_level NOT NULL,
  climate_risk_exposure DECIMAL(5,2),
  governance_score DECIMAL(5,2),
  social_score DECIMAL(5,2),
  analysis_summary TEXT,
  recommendations JSONB DEFAULT '[]',
  data_sources JSONB DEFAULT '[]',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Credit Scores for Financial Inclusion
CREATE TABLE public.credit_profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  applicant_name TEXT NOT NULL,
  traditional_score DECIMAL(5,2),
  alternative_score DECIMAL(5,2),
  combined_score DECIMAL(5,2),
  income_stability DECIMAL(5,2),
  payment_behavior DECIMAL(5,2),
  community_trust_score DECIMAL(5,2),
  recommended_products JSONB DEFAULT '[]',
  risk_factors JSONB DEFAULT '[]',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- SDG Metrics tracking
CREATE TABLE public.sdg_metrics (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  portfolio_id UUID REFERENCES public.portfolios(id) ON DELETE CASCADE,
  sdg_goal sdg_goal NOT NULL,
  contribution_score DECIMAL(5,2) NOT NULL,
  impact_description TEXT,
  measured_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Agent activity logs for transparency
CREATE TABLE public.agent_activities (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  agent_type agent_type NOT NULL,
  action TEXT NOT NULL,
  input_summary TEXT,
  output_summary TEXT,
  confidence_score DECIMAL(5,2),
  processing_time_ms INTEGER,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Enable RLS on all tables
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.portfolios ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.assets ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.risk_assessments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.credit_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sdg_metrics ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.agent_activities ENABLE ROW LEVEL SECURITY;

-- RLS Policies for profiles
CREATE POLICY "Users can view own profile" ON public.profiles FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can update own profile" ON public.profiles FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own profile" ON public.profiles FOR INSERT WITH CHECK (auth.uid() = user_id);

-- RLS Policies for portfolios
CREATE POLICY "Users can view own portfolios" ON public.portfolios FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can create own portfolios" ON public.portfolios FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own portfolios" ON public.portfolios FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete own portfolios" ON public.portfolios FOR DELETE USING (auth.uid() = user_id);

-- RLS Policies for assets
CREATE POLICY "Users can view own assets" ON public.assets FOR SELECT 
  USING (EXISTS (SELECT 1 FROM public.portfolios WHERE portfolios.id = assets.portfolio_id AND portfolios.user_id = auth.uid()));
CREATE POLICY "Users can create own assets" ON public.assets FOR INSERT 
  WITH CHECK (EXISTS (SELECT 1 FROM public.portfolios WHERE portfolios.id = assets.portfolio_id AND portfolios.user_id = auth.uid()));
CREATE POLICY "Users can update own assets" ON public.assets FOR UPDATE 
  USING (EXISTS (SELECT 1 FROM public.portfolios WHERE portfolios.id = assets.portfolio_id AND portfolios.user_id = auth.uid()));
CREATE POLICY "Users can delete own assets" ON public.assets FOR DELETE 
  USING (EXISTS (SELECT 1 FROM public.portfolios WHERE portfolios.id = assets.portfolio_id AND portfolios.user_id = auth.uid()));

-- RLS Policies for risk_assessments
CREATE POLICY "Users can view own risk assessments" ON public.risk_assessments FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can create own risk assessments" ON public.risk_assessments FOR INSERT WITH CHECK (auth.uid() = user_id);

-- RLS Policies for credit_profiles
CREATE POLICY "Users can view own credit profiles" ON public.credit_profiles FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can create own credit profiles" ON public.credit_profiles FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own credit profiles" ON public.credit_profiles FOR UPDATE USING (auth.uid() = user_id);

-- RLS Policies for sdg_metrics
CREATE POLICY "Users can view own sdg metrics" ON public.sdg_metrics FOR SELECT 
  USING (EXISTS (SELECT 1 FROM public.portfolios WHERE portfolios.id = sdg_metrics.portfolio_id AND portfolios.user_id = auth.uid()));
CREATE POLICY "Users can create own sdg metrics" ON public.sdg_metrics FOR INSERT 
  WITH CHECK (EXISTS (SELECT 1 FROM public.portfolios WHERE portfolios.id = sdg_metrics.portfolio_id AND portfolios.user_id = auth.uid()));

-- RLS Policies for agent_activities
CREATE POLICY "Users can view own agent activities" ON public.agent_activities FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can create own agent activities" ON public.agent_activities FOR INSERT WITH CHECK (auth.uid() = user_id);

-- Trigger for profile creation on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (user_id, full_name)
  VALUES (NEW.id, NEW.raw_user_meta_data ->> 'full_name');
  RETURN NEW;
END;
$$;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Update timestamp function
CREATE OR REPLACE FUNCTION public.update_updated_at()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

-- Add update triggers
CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();
CREATE TRIGGER update_portfolios_updated_at BEFORE UPDATE ON public.portfolios FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();
CREATE TRIGGER update_assets_updated_at BEFORE UPDATE ON public.assets FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();
CREATE TRIGGER update_credit_profiles_updated_at BEFORE UPDATE ON public.credit_profiles FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();
