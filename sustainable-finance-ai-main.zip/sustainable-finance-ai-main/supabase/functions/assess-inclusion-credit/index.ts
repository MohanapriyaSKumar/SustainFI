import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { applicantName, occupation, region, additionalContext } = await req.json();
    const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');

    const response = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${LOVABLE_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'google/gemini-2.5-flash',
        messages: [
          {
            role: 'system',
            content: `You are an AI financial inclusion agent specializing in micro-credit scoring for underserved populations. Use alternative data signals to assess creditworthiness fairly. Return JSON only.`
          },
          {
            role: 'user',
            content: `Assess this applicant for inclusive micro-credit:
Name: ${applicantName}
Occupation: ${occupation}
Region: ${region || 'Not specified'}
Additional Context: ${additionalContext || 'None provided'}

Return JSON with:
- traditionalScore (0-100, simulated)
- alternativeScore (0-100, based on non-traditional signals)
- combinedScore (0-100, weighted average)
- incomeStability (0-100)
- paymentBehavior (0-100)
- communityTrustScore (0-100)
- recommendedProducts (array of 3 objects with: name, description, maxAmount in USD)
- riskFactors (array of 2-3 considerations)
- approvalLikelihood ("High", "Medium", "Low")
- summary (2-3 sentences)`
          }
        ],
        response_format: { type: 'json_object' },
      }),
    });

    if (!response.ok) {
      throw new Error(`AI gateway error: ${response.status}`);
    }

    const data = await response.json();
    const content = data.choices[0].message.content;
    const assessment = JSON.parse(content);

    return new Response(JSON.stringify({ assessment }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (error) {
    console.error('Inclusion credit assessment error:', error);
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
