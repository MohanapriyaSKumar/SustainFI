import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { investmentAmount, riskTolerance, sustainabilityPriority } = await req.json();
    const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');

    const response = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${LOVABLE_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'google/gemini-2.5-flash',
        messages: [
          {
            role: 'system',
            content: `You are an AI portfolio advisory agent specializing in sustainable and impact investing. Create optimized portfolios balancing returns with ESG criteria. Return JSON only.`
          },
          {
            role: 'user',
            content: `Create an optimized sustainable portfolio:
Investment Amount: $${investmentAmount}
Risk Tolerance: ${riskTolerance}% (0=conservative, 100=aggressive)
Sustainability Priority: ${sustainabilityPriority}% (0=returns focus, 100=impact focus)

Return JSON with:
- recommendations (array of 5 assets, each with: name, allocation %, esgScore 0-100, expectedReturn %, sdgAlignment array of SDG names)
- overallESGScore (0-100)
- expectedReturn (annual %)
- riskLevel ("Low", "Medium", "High")
- carbonFootprint (tons CO2 annually)
- summary (2-3 sentences)`
          }
        ],
        response_format: { type: 'json_object' },
      }),
    });

    if (!response.ok) {
      throw new Error(`AI gateway error: ${response.status}`);
    }

    const data = await response.json();
    const content = data.choices[0].message.content;
    const analysis = JSON.parse(content);

    return new Response(JSON.stringify({ analysis }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (error) {
    console.error('Portfolio optimization error:', error);
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
