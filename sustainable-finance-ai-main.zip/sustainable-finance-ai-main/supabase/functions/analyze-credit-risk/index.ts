import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { entityName, entityType, financialData } = await req.json();
    const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');

    const response = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${LOVABLE_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'google/gemini-2.5-flash',
        messages: [
          {
            role: 'system',
            content: `You are an AI credit and risk assessment agent specializing in sustainable finance. Analyze entities for both financial creditworthiness and ESG/sustainability risk. Return JSON only.`
          },
          {
            role: 'user',
            content: `Analyze this entity for credit and sustainability risk:
Entity: ${entityName}
Type: ${entityType}
Additional Context: ${financialData || 'None provided'}

Return a JSON object with:
- financialScore (0-100)
- sustainabilityScore (0-100)
- overallRisk ("low", "medium", "high", or "critical")
- climateRiskExposure (0-100)
- governanceScore (0-100)
- socialScore (0-100)
- summary (2-3 sentences)
- recommendations (array of 3 actionable items)`
          }
        ],
        response_format: { type: 'json_object' },
      }),
    });

    if (!response.ok) {
      throw new Error(`AI gateway error: ${response.status}`);
    }

    const data = await response.json();
    const content = data.choices[0].message.content;
    const assessment = JSON.parse(content);

    return new Response(JSON.stringify({ assessment }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (error) {
    console.error('Credit risk analysis error:', error);
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
