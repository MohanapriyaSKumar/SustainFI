import { ReactNode } from 'react';
import { cn } from '@/lib/utils';
import { TrendingUp, TrendingDown, Minus } from 'lucide-react';

interface MetricCardProps {
  title: string;
  value: string | number;
  change?: number;
  changeLabel?: string;
  icon?: ReactNode;
  variant?: 'default' | 'success' | 'warning' | 'danger';
  className?: string;
}

export const MetricCard = ({
  title,
  value,
  change,
  changeLabel,
  icon,
  variant = 'default',
  className,
}: MetricCardProps) => {
  const variantStyles = {
    default: 'border-border',
    success: 'border-sustainable/30',
    warning: 'border-risk-amber/30',
    danger: 'border-risk-red/30',
  };

  const getTrendIcon = () => {
    if (change === undefined) return null;
    if (change > 0) return <TrendingUp className="h-4 w-4 text-sustainable" />;
    if (change < 0) return <TrendingDown className="h-4 w-4 text-risk-red" />;
    return <Minus className="h-4 w-4 text-muted-foreground" />;
  };

  return (
    <div
      className={cn(
        'glass-card p-5 transition-all duration-300 hover:border-primary/30',
        variantStyles[variant],
        className
      )}
    >
      <div className="flex items-start justify-between">
        <div className="space-y-1">
          <p className="metric-label">{title}</p>
          <p className="metric-value text-foreground">{value}</p>
        </div>
        {icon && (
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
            {icon}
          </div>
        )}
      </div>
      
      {change !== undefined && (
        <div className="mt-3 flex items-center gap-2">
          {getTrendIcon()}
          <span
            className={cn(
              'text-sm font-medium',
              change > 0 ? 'text-sustainable' : change < 0 ? 'text-risk-red' : 'text-muted-foreground'
            )}
          >
            {change > 0 ? '+' : ''}{change}%
          </span>
          {changeLabel && (
            <span className="text-sm text-muted-foreground">{changeLabel}</span>
          )}
        </div>
      )}
    </div>
  );
};
