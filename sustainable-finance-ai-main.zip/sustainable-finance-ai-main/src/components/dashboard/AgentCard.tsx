import { ReactNode } from 'react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

interface AgentCardProps {
  title: string;
  description: string;
  icon: ReactNode;
  status: 'active' | 'idle' | 'processing';
  metrics: { label: string; value: string }[];
  href: string;
  gradient: 'sustainable' | 'accent' | 'inclusion';
}

export const AgentCard = ({
  title,
  description,
  icon,
  status,
  metrics,
  href,
  gradient,
}: AgentCardProps) => {
  const gradientStyles = {
    sustainable: 'from-sustainable/20 to-sustainable/5',
    accent: 'from-accentBlue/20 to-accentBlue/5',
    inclusion: 'from-inclusion-teal/20 to-inclusion-teal/5',
  };

  const iconBgStyles = {
    sustainable: 'bg-sustainable/20 text-sustainable',
    accent: 'bg-accentBlue/20 text-accentBlue',
    inclusion: 'bg-inclusion-teal/20 text-inclusion-teal',
  };

  const statusColors = {
    active: 'bg-sustainable',
    idle: 'bg-muted-foreground',
    processing: 'bg-risk-amber animate-pulse',
  };

  return (
    <div className="glass-card overflow-hidden group hover:border-primary/30 transition-all duration-300">
      <div className={cn('h-1 w-full bg-gradient-to-r', gradientStyles[gradient])} />
      
      <div className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div className={cn('flex h-12 w-12 items-center justify-center rounded-xl', iconBgStyles[gradient])}>
            {icon}
          </div>
          <div className="flex items-center gap-2">
            <div className={cn('h-2 w-2 rounded-full', statusColors[status])} />
            <span className="text-xs text-muted-foreground capitalize">{status}</span>
          </div>
        </div>

        <h3 className="text-lg font-semibold text-foreground mb-2">{title}</h3>
        <p className="text-sm text-muted-foreground mb-6">{description}</p>

        <div className="grid grid-cols-2 gap-4 mb-6">
          {metrics.map((metric, idx) => (
            <div key={idx} className="space-y-1">
              <p className="text-xs text-muted-foreground uppercase tracking-wider">{metric.label}</p>
              <p className="text-lg font-semibold font-mono text-foreground">{metric.value}</p>
            </div>
          ))}
        </div>

        <Button asChild variant="secondary" className="w-full group-hover:bg-primary group-hover:text-primary-foreground transition-all">
          <Link to={href}>
            Open Agent
            <ArrowRight className="ml-2 h-4 w-4" />
          </Link>
        </Button>
      </div>
    </div>
  );
};
