import { cn } from '@/lib/utils';

interface SDGData {
  goal: number;
  name: string;
  score: number;
}

interface SDGWheelProps {
  data: SDGData[];
  size?: number;
}

const SDG_COLORS: Record<number, string> = {
  1: '#E5243B',
  2: '#DDA63A',
  3: '#4C9F38',
  4: '#C5192D',
  5: '#FF3A21',
  6: '#26BDE2',
  7: '#FCC30B',
  8: '#A21942',
  9: '#FD6925',
  10: '#DD1367',
  11: '#FD9D24',
  12: '#BF8B2E',
  13: '#3F7E44',
  14: '#0A97D9',
  15: '#56C02B',
  16: '#00689D',
  17: '#19486A',
};

export const SDGWheel = ({ data, size = 280 }: SDGWheelProps) => {
  const center = size / 2;
  const radius = size / 2 - 20;
  const innerRadius = radius * 0.4;

  return (
    <div className="relative" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="transform -rotate-90">
        {data.map((sdg, index) => {
          const angle = (360 / data.length) * index;
          const angleRad = (angle * Math.PI) / 180;
          const nextAngle = (360 / data.length) * (index + 1);
          const nextAngleRad = (nextAngle * Math.PI) / 180;
          
          const outerRadius = innerRadius + (radius - innerRadius) * (sdg.score / 100);
          
          const x1 = center + innerRadius * Math.cos(angleRad);
          const y1 = center + innerRadius * Math.sin(angleRad);
          const x2 = center + outerRadius * Math.cos(angleRad);
          const y2 = center + outerRadius * Math.sin(angleRad);
          const x3 = center + outerRadius * Math.cos(nextAngleRad);
          const y3 = center + outerRadius * Math.sin(nextAngleRad);
          const x4 = center + innerRadius * Math.cos(nextAngleRad);
          const y4 = center + innerRadius * Math.sin(nextAngleRad);

          const largeArcFlag = nextAngle - angle > 180 ? 1 : 0;

          const pathD = `
            M ${x1} ${y1}
            L ${x2} ${y2}
            A ${outerRadius} ${outerRadius} 0 ${largeArcFlag} 1 ${x3} ${y3}
            L ${x4} ${y4}
            A ${innerRadius} ${innerRadius} 0 ${largeArcFlag} 0 ${x1} ${y1}
            Z
          `;

          return (
            <path
              key={sdg.goal}
              d={pathD}
              fill={SDG_COLORS[sdg.goal] || '#666'}
              opacity={0.8}
              className="transition-all duration-300 hover:opacity-100 cursor-pointer"
            >
              <title>{`SDG ${sdg.goal}: ${sdg.name} - ${sdg.score}%`}</title>
            </path>
          );
        })}
        
        {/* Center circle */}
        <circle
          cx={center}
          cy={center}
          r={innerRadius - 5}
          fill="hsl(var(--card))"
          stroke="hsl(var(--border))"
          strokeWidth="1"
        />
      </svg>
      
      {/* Center text */}
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="text-center">
          <p className="text-2xl font-bold text-foreground">
            {Math.round(data.reduce((acc, d) => acc + d.score, 0) / data.length)}%
          </p>
          <p className="text-xs text-muted-foreground">SDG Score</p>
        </div>
      </div>
    </div>
  );
};
