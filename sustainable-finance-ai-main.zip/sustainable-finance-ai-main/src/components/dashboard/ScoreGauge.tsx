import { cn } from '@/lib/utils';

interface ScoreGaugeProps {
  value: number;
  maxValue?: number;
  label: string;
  variant?: 'sustainable' | 'risk' | 'neutral';
  size?: 'sm' | 'md' | 'lg';
}

export const ScoreGauge = ({
  value,
  maxValue = 100,
  label,
  variant = 'neutral',
  size = 'md',
}: ScoreGaugeProps) => {
  const percentage = (value / maxValue) * 100;
  
  const sizeStyles = {
    sm: { width: 80, strokeWidth: 6, fontSize: 'text-lg' },
    md: { width: 120, strokeWidth: 8, fontSize: 'text-2xl' },
    lg: { width: 160, strokeWidth: 10, fontSize: 'text-3xl' },
  };

  const variantColors = {
    sustainable: 'stroke-sustainable',
    risk: percentage > 70 ? 'stroke-risk-red' : percentage > 40 ? 'stroke-risk-amber' : 'stroke-sustainable',
    neutral: 'stroke-accentBlue',
  };

  const { width, strokeWidth, fontSize } = sizeStyles[size];
  const radius = (width - strokeWidth) / 2;
  const circumference = radius * 2 * Math.PI;
  const offset = circumference - (percentage / 100) * circumference;

  return (
    <div className="flex flex-col items-center gap-2">
      <div className="relative" style={{ width, height: width }}>
        <svg width={width} height={width} className="transform -rotate-90">
          {/* Background circle */}
          <circle
            cx={width / 2}
            cy={width / 2}
            r={radius}
            fill="none"
            stroke="hsl(var(--muted))"
            strokeWidth={strokeWidth}
          />
          {/* Progress circle */}
          <circle
            cx={width / 2}
            cy={width / 2}
            r={radius}
            fill="none"
            className={cn('transition-all duration-700', variantColors[variant])}
            strokeWidth={strokeWidth}
            strokeDasharray={circumference}
            strokeDashoffset={offset}
            strokeLinecap="round"
          />
        </svg>
        
        <div className="absolute inset-0 flex items-center justify-center">
          <span className={cn('font-bold font-mono', fontSize)}>{value}</span>
        </div>
      </div>
      <p className="text-sm text-muted-foreground text-center">{label}</p>
    </div>
  );
};
