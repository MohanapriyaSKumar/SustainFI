export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.1"
  }
  public: {
    Tables: {
      agent_activities: {
        Row: {
          action: string
          agent_type: Database["public"]["Enums"]["agent_type"]
          confidence_score: number | null
          created_at: string
          id: string
          input_summary: string | null
          output_summary: string | null
          processing_time_ms: number | null
          user_id: string
        }
        Insert: {
          action: string
          agent_type: Database["public"]["Enums"]["agent_type"]
          confidence_score?: number | null
          created_at?: string
          id?: string
          input_summary?: string | null
          output_summary?: string | null
          processing_time_ms?: number | null
          user_id: string
        }
        Update: {
          action?: string
          agent_type?: Database["public"]["Enums"]["agent_type"]
          confidence_score?: number | null
          created_at?: string
          id?: string
          input_summary?: string | null
          output_summary?: string | null
          processing_time_ms?: number | null
          user_id?: string
        }
        Relationships: []
      }
      assets: {
        Row: {
          asset_type: string
          carbon_footprint: number | null
          created_at: string
          current_price: number | null
          esg_score: number | null
          id: string
          metadata: Json | null
          name: string
          portfolio_id: string
          purchase_price: number | null
          quantity: number | null
          sdg_contributions: Json | null
          ticker: string | null
          updated_at: string
        }
        Insert: {
          asset_type: string
          carbon_footprint?: number | null
          created_at?: string
          current_price?: number | null
          esg_score?: number | null
          id?: string
          metadata?: Json | null
          name: string
          portfolio_id: string
          purchase_price?: number | null
          quantity?: number | null
          sdg_contributions?: Json | null
          ticker?: string | null
          updated_at?: string
        }
        Update: {
          asset_type?: string
          carbon_footprint?: number | null
          created_at?: string
          current_price?: number | null
          esg_score?: number | null
          id?: string
          metadata?: Json | null
          name?: string
          portfolio_id?: string
          purchase_price?: number | null
          quantity?: number | null
          sdg_contributions?: Json | null
          ticker?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "assets_portfolio_id_fkey"
            columns: ["portfolio_id"]
            isOneToOne: false
            referencedRelation: "portfolios"
            referencedColumns: ["id"]
          },
        ]
      }
      credit_profiles: {
        Row: {
          alternative_score: number | null
          applicant_name: string
          combined_score: number | null
          community_trust_score: number | null
          created_at: string
          id: string
          income_stability: number | null
          payment_behavior: number | null
          recommended_products: Json | null
          risk_factors: Json | null
          traditional_score: number | null
          updated_at: string
          user_id: string
        }
        Insert: {
          alternative_score?: number | null
          applicant_name: string
          combined_score?: number | null
          community_trust_score?: number | null
          created_at?: string
          id?: string
          income_stability?: number | null
          payment_behavior?: number | null
          recommended_products?: Json | null
          risk_factors?: Json | null
          traditional_score?: number | null
          updated_at?: string
          user_id: string
        }
        Update: {
          alternative_score?: number | null
          applicant_name?: string
          combined_score?: number | null
          community_trust_score?: number | null
          created_at?: string
          id?: string
          income_stability?: number | null
          payment_behavior?: number | null
          recommended_products?: Json | null
          risk_factors?: Json | null
          traditional_score?: number | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      portfolios: {
        Row: {
          created_at: string
          description: string | null
          id: string
          name: string
          risk_score: number | null
          sdg_alignment: Json | null
          sustainability_score: number | null
          total_value: number | null
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          name: string
          risk_score?: number | null
          sdg_alignment?: Json | null
          sustainability_score?: number | null
          total_value?: number | null
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          name?: string
          risk_score?: number | null
          sdg_alignment?: Json | null
          sustainability_score?: number | null
          total_value?: number | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          avatar_url: string | null
          created_at: string
          full_name: string | null
          id: string
          organization: string | null
          preferences: Json | null
          role: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string
          full_name?: string | null
          id?: string
          organization?: string | null
          preferences?: Json | null
          role?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          avatar_url?: string | null
          created_at?: string
          full_name?: string | null
          id?: string
          organization?: string | null
          preferences?: Json | null
          role?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      risk_assessments: {
        Row: {
          analysis_summary: string | null
          climate_risk_exposure: number | null
          created_at: string
          data_sources: Json | null
          entity_name: string
          entity_type: string
          financial_score: number
          governance_score: number | null
          id: string
          overall_risk: Database["public"]["Enums"]["risk_level"]
          recommendations: Json | null
          social_score: number | null
          sustainability_score: number
          user_id: string
        }
        Insert: {
          analysis_summary?: string | null
          climate_risk_exposure?: number | null
          created_at?: string
          data_sources?: Json | null
          entity_name: string
          entity_type: string
          financial_score: number
          governance_score?: number | null
          id?: string
          overall_risk: Database["public"]["Enums"]["risk_level"]
          recommendations?: Json | null
          social_score?: number | null
          sustainability_score: number
          user_id: string
        }
        Update: {
          analysis_summary?: string | null
          climate_risk_exposure?: number | null
          created_at?: string
          data_sources?: Json | null
          entity_name?: string
          entity_type?: string
          financial_score?: number
          governance_score?: number | null
          id?: string
          overall_risk?: Database["public"]["Enums"]["risk_level"]
          recommendations?: Json | null
          social_score?: number | null
          sustainability_score?: number
          user_id?: string
        }
        Relationships: []
      }
      sdg_metrics: {
        Row: {
          contribution_score: number
          id: string
          impact_description: string | null
          measured_at: string
          portfolio_id: string | null
          sdg_goal: Database["public"]["Enums"]["sdg_goal"]
        }
        Insert: {
          contribution_score: number
          id?: string
          impact_description?: string | null
          measured_at?: string
          portfolio_id?: string | null
          sdg_goal: Database["public"]["Enums"]["sdg_goal"]
        }
        Update: {
          contribution_score?: number
          id?: string
          impact_description?: string | null
          measured_at?: string
          portfolio_id?: string | null
          sdg_goal?: Database["public"]["Enums"]["sdg_goal"]
        }
        Relationships: [
          {
            foreignKeyName: "sdg_metrics_portfolio_id_fkey"
            columns: ["portfolio_id"]
            isOneToOne: false
            referencedRelation: "portfolios"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      agent_type: "credit_risk" | "portfolio_advisory" | "financial_inclusion"
      risk_level: "low" | "medium" | "high" | "critical"
      sdg_goal:
        | "no_poverty"
        | "zero_hunger"
        | "good_health"
        | "quality_education"
        | "gender_equality"
        | "clean_water"
        | "affordable_energy"
        | "decent_work"
        | "industry_innovation"
        | "reduced_inequalities"
        | "sustainable_cities"
        | "responsible_consumption"
        | "climate_action"
        | "life_below_water"
        | "life_on_land"
        | "peace_justice"
        | "partnerships"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      agent_type: ["credit_risk", "portfolio_advisory", "financial_inclusion"],
      risk_level: ["low", "medium", "high", "critical"],
      sdg_goal: [
        "no_poverty",
        "zero_hunger",
        "good_health",
        "quality_education",
        "gender_equality",
        "clean_water",
        "affordable_energy",
        "decent_work",
        "industry_innovation",
        "reduced_inequalities",
        "sustainable_cities",
        "responsible_consumption",
        "climate_action",
        "life_below_water",
        "life_on_land",
        "peace_justice",
        "partnerships",
      ],
    },
  },
} as const
