import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ScoreGauge } from '@/components/dashboard/ScoreGauge';
import { useToast } from '@/hooks/use-toast';
import { Users, Sparkles, Wallet, ShieldCheck, Heart, Loader2, CheckCircle } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';

interface CreditAssessment {
  traditionalScore: number;
  alternativeScore: number;
  combinedScore: number;
  incomeStability: number;
  paymentBehavior: number;
  communityTrustScore: number;
  recommendedProducts: { name: string; description: string; maxAmount: number }[];
  riskFactors: string[];
  approvalLikelihood: string;
  summary: string;
}

export default function Inclusion() {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const [applicantName, setApplicantName] = useState('');
  const [occupation, setOccupation] = useState('');
  const [region, setRegion] = useState('');
  const [additionalContext, setAdditionalContext] = useState('');
  const [analyzing, setAnalyzing] = useState(false);
  const [assessment, setAssessment] = useState<CreditAssessment | null>(null);

  useEffect(() => {
    if (!loading && !user) {
      navigate('/auth');
    }
  }, [user, loading, navigate]);

  const handleAssess = async () => {
    if (!applicantName || !occupation) {
      toast({
        title: 'Missing Information',
        description: 'Please provide applicant name and occupation.',
        variant: 'destructive',
      });
      return;
    }

    setAnalyzing(true);
    
    try {
      const { data, error } = await supabase.functions.invoke('assess-inclusion-credit', {
        body: {
          applicantName,
          occupation,
          region,
          additionalContext,
        },
      });

      if (error) throw error;

      setAssessment(data.assessment);
      
      // Save to database
      await supabase.from('credit_profiles').insert({
        user_id: user?.id,
        applicant_name: applicantName,
        traditional_score: data.assessment.traditionalScore,
        alternative_score: data.assessment.alternativeScore,
        combined_score: data.assessment.combinedScore,
        income_stability: data.assessment.incomeStability,
        payment_behavior: data.assessment.paymentBehavior,
        community_trust_score: data.assessment.communityTrustScore,
        recommended_products: data.assessment.recommendedProducts,
        risk_factors: data.assessment.riskFactors,
      });

      toast({
        title: 'Assessment Complete',
        description: 'Credit profile has been generated successfully.',
      });
    } catch (error) {
      console.error('Assessment error:', error);
      toast({
        title: 'Assessment Failed',
        description: 'Unable to complete the credit assessment. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setAnalyzing(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-pulse text-muted-foreground">Loading...</div>
      </div>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6 animate-fade-in">
        {/* Header */}
        <div className="flex items-center gap-4">
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-inclusion-teal/20">
            <Users className="h-6 w-6 text-inclusion-teal" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-foreground">Financial Inclusion</h1>
            <p className="text-muted-foreground">
              AI-driven micro-credit scoring for underserved communities
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Input Form */}
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Sparkles className="h-5 w-5 text-primary" />
                New Credit Assessment
              </CardTitle>
              <CardDescription>
                Enter applicant details for inclusive credit scoring
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="applicantName">Applicant Name</Label>
                <Input
                  id="applicantName"
                  placeholder="e.g., Maria Santos"
                  value={applicantName}
                  onChange={(e) => setApplicantName(e.target.value)}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="occupation">Occupation / Income Source</Label>
                <Select value={occupation} onValueChange={setOccupation}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select occupation type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="farmer">Farmer / Agricultural</SelectItem>
                    <SelectItem value="artisan">Artisan / Craftsperson</SelectItem>
                    <SelectItem value="trader">Small Trader / Vendor</SelectItem>
                    <SelectItem value="service">Service Provider</SelectItem>
                    <SelectItem value="informal">Informal Sector Worker</SelectItem>
                    <SelectItem value="seasonal">Seasonal Worker</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="region">Region / Community</Label>
                <Input
                  id="region"
                  placeholder="e.g., Rural Maharashtra, India"
                  value={region}
                  onChange={(e) => setRegion(e.target.value)}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="context">Additional Context (Optional)</Label>
                <Textarea
                  id="context"
                  placeholder="Mobile payment history, community standing, seasonal income patterns, family support network..."
                  value={additionalContext}
                  onChange={(e) => setAdditionalContext(e.target.value)}
                  rows={3}
                />
              </div>
              
              <Button 
                className="w-full" 
                onClick={handleAssess}
                disabled={analyzing}
              >
                {analyzing ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Assessing...
                  </>
                ) : (
                  <>
                    <Sparkles className="mr-2 h-4 w-4" />
                    Generate Credit Profile
                  </>
                )}
              </Button>
            </CardContent>
          </Card>

          {/* Results */}
          {assessment && (
            <Card className="glass-card">
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>Credit Profile</span>
                  <span className={`text-sm font-medium px-3 py-1 rounded-full ${
                    assessment.approvalLikelihood === 'High' 
                      ? 'bg-sustainable/20 text-sustainable'
                      : assessment.approvalLikelihood === 'Medium'
                      ? 'bg-risk-amber/20 text-risk-amber'
                      : 'bg-risk-red/20 text-risk-red'
                  }`}>
                    {assessment.approvalLikelihood} Approval Likelihood
                  </span>
                </CardTitle>
                <CardDescription>{applicantName}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Scores */}
                <div className="grid grid-cols-3 gap-4">
                  <ScoreGauge 
                    value={assessment.traditionalScore} 
                    label="Traditional" 
                    variant="neutral"
                    size="sm"
                  />
                  <ScoreGauge 
                    value={assessment.alternativeScore} 
                    label="Alternative" 
                    variant="sustainable"
                    size="sm"
                  />
                  <ScoreGauge 
                    value={assessment.combinedScore} 
                    label="Combined" 
                    variant="sustainable"
                    size="sm"
                  />
                </div>

                {/* Additional Metrics */}
                <div className="grid grid-cols-3 gap-4">
                  <div className="text-center p-3 rounded-lg bg-muted/50">
                    <Wallet className="h-5 w-5 mx-auto mb-1 text-inclusion-teal" />
                    <p className="text-lg font-bold font-mono text-foreground">{assessment.incomeStability}</p>
                    <p className="text-xs text-muted-foreground">Income Stability</p>
                  </div>
                  <div className="text-center p-3 rounded-lg bg-muted/50">
                    <ShieldCheck className="h-5 w-5 mx-auto mb-1 text-accentBlue" />
                    <p className="text-lg font-bold font-mono text-foreground">{assessment.paymentBehavior}</p>
                    <p className="text-xs text-muted-foreground">Payment History</p>
                  </div>
                  <div className="text-center p-3 rounded-lg bg-muted/50">
                    <Heart className="h-5 w-5 mx-auto mb-1 text-sustainable" />
                    <p className="text-lg font-bold font-mono text-foreground">{assessment.communityTrustScore}</p>
                    <p className="text-xs text-muted-foreground">Community Trust</p>
                  </div>
                </div>

                {/* Summary */}
                <div className="space-y-2">
                  <h4 className="text-sm font-medium text-foreground">AI Assessment</h4>
                  <p className="text-sm text-muted-foreground">{assessment.summary}</p>
                </div>

                {/* Recommended Products */}
                <div className="space-y-2">
                  <h4 className="text-sm font-medium text-foreground">Recommended Products</h4>
                  <div className="space-y-2">
                    {assessment.recommendedProducts.map((product, idx) => (
                      <div key={idx} className="p-3 rounded-lg bg-sustainable/10 border border-sustainable/20">
                        <div className="flex items-center justify-between mb-1">
                          <span className="font-medium text-foreground">{product.name}</span>
                          <span className="text-sm font-mono text-sustainable">Up to ${product.maxAmount.toLocaleString()}</span>
                        </div>
                        <p className="text-xs text-muted-foreground">{product.description}</p>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Risk Factors */}
                {assessment.riskFactors.length > 0 && (
                  <div className="space-y-2">
                    <h4 className="text-sm font-medium text-foreground">Considerations</h4>
                    <ul className="space-y-1">
                      {assessment.riskFactors.map((factor, idx) => (
                        <li key={idx} className="flex items-start gap-2 text-sm text-muted-foreground">
                          <CheckCircle className="h-4 w-4 text-risk-amber mt-0.5 flex-shrink-0" />
                          {factor}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {!assessment && (
            <div className="glass-card flex items-center justify-center min-h-[400px]">
              <div className="text-center space-y-4">
                <Users className="h-16 w-16 text-muted-foreground/30 mx-auto" />
                <div>
                  <h3 className="text-lg font-medium text-foreground">No Assessment Yet</h3>
                  <p className="text-sm text-muted-foreground">
                    Enter applicant details and generate an inclusive credit profile
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </DashboardLayout>
  );
}
