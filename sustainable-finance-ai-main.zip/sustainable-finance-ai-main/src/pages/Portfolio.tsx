import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { ScoreGauge } from '@/components/dashboard/ScoreGauge';
import { useToast } from '@/hooks/use-toast';
import { TrendingUp, Sparkles, Leaf, DollarSign, Scale, Loader2, PieChart } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';

interface PortfolioRecommendation {
  name: string;
  allocation: number;
  esgScore: number;
  expectedReturn: number;
  sdgAlignment: string[];
}

interface PortfolioAnalysis {
  recommendations: PortfolioRecommendation[];
  overallESGScore: number;
  expectedReturn: number;
  riskLevel: string;
  carbonFootprint: number;
  summary: string;
}

export default function Portfolio() {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const [investmentAmount, setInvestmentAmount] = useState('100000');
  const [riskTolerance, setRiskTolerance] = useState([50]);
  const [sustainabilityPriority, setSustainabilityPriority] = useState([70]);
  const [analyzing, setAnalyzing] = useState(false);
  const [analysis, setAnalysis] = useState<PortfolioAnalysis | null>(null);

  useEffect(() => {
    if (!loading && !user) {
      navigate('/auth');
    }
  }, [user, loading, navigate]);

  const handleOptimize = async () => {
    setAnalyzing(true);
    
    try {
      const { data, error } = await supabase.functions.invoke('optimize-portfolio', {
        body: {
          investmentAmount: parseFloat(investmentAmount),
          riskTolerance: riskTolerance[0],
          sustainabilityPriority: sustainabilityPriority[0],
        },
      });

      if (error) throw error;

      setAnalysis(data.analysis);
      
      toast({
        title: 'Portfolio Optimized',
        description: 'Your sustainable portfolio has been generated.',
      });
    } catch (error) {
      console.error('Optimization error:', error);
      toast({
        title: 'Optimization Failed',
        description: 'Unable to optimize portfolio. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setAnalyzing(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-pulse text-muted-foreground">Loading...</div>
      </div>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6 animate-fade-in">
        {/* Header */}
        <div className="flex items-center gap-4">
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-accentBlue/20">
            <TrendingUp className="h-6 w-6 text-accentBlue" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-foreground">Portfolio Advisory</h1>
            <p className="text-muted-foreground">
              AI-powered sustainable investment optimization
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Input Form */}
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Sparkles className="h-5 w-5 text-primary" />
                Investment Preferences
              </CardTitle>
              <CardDescription>
                Configure your investment goals and sustainability priorities
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="amount">Investment Amount ($)</Label>
                <Input
                  id="amount"
                  type="number"
                  placeholder="100000"
                  value={investmentAmount}
                  onChange={(e) => setInvestmentAmount(e.target.value)}
                />
              </div>
              
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <Label>Risk Tolerance</Label>
                  <span className="text-sm text-muted-foreground">{riskTolerance[0]}%</span>
                </div>
                <Slider
                  value={riskTolerance}
                  onValueChange={setRiskTolerance}
                  max={100}
                  step={5}
                  className="w-full"
                />
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>Conservative</span>
                  <span>Aggressive</span>
                </div>
              </div>
              
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <Label>Sustainability Priority</Label>
                  <span className="text-sm text-muted-foreground">{sustainabilityPriority[0]}%</span>
                </div>
                <Slider
                  value={sustainabilityPriority}
                  onValueChange={setSustainabilityPriority}
                  max={100}
                  step={5}
                  className="w-full"
                />
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>Returns Focus</span>
                  <span>Impact Focus</span>
                </div>
              </div>
              
              <Button 
                className="w-full" 
                onClick={handleOptimize}
                disabled={analyzing}
              >
                {analyzing ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Optimizing...
                  </>
                ) : (
                  <>
                    <Sparkles className="mr-2 h-4 w-4" />
                    Generate Portfolio
                  </>
                )}
              </Button>
            </CardContent>
          </Card>

          {/* Results */}
          {analysis ? (
            <>
              {/* Portfolio Metrics */}
              <Card className="glass-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <PieChart className="h-5 w-5 text-accentBlue" />
                    Portfolio Overview
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-2 gap-4">
                    <ScoreGauge 
                      value={analysis.overallESGScore} 
                      label="ESG Score" 
                      variant="sustainable"
                      size="sm"
                    />
                    <ScoreGauge 
                      value={Math.round(analysis.expectedReturn * 10)} 
                      label="Expected Return %" 
                      variant="neutral"
                      size="sm"
                    />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div className="p-4 rounded-lg bg-muted/50 text-center">
                      <Scale className="h-6 w-6 text-muted-foreground mx-auto mb-2" />
                      <p className="text-lg font-bold text-foreground">{analysis.riskLevel}</p>
                      <p className="text-xs text-muted-foreground">Risk Level</p>
                    </div>
                    <div className="p-4 rounded-lg bg-muted/50 text-center">
                      <Leaf className="h-6 w-6 text-sustainable mx-auto mb-2" />
                      <p className="text-lg font-bold text-foreground">{analysis.carbonFootprint}t</p>
                      <p className="text-xs text-muted-foreground">CO₂ Footprint</p>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <h4 className="text-sm font-medium text-foreground">AI Summary</h4>
                    <p className="text-sm text-muted-foreground">{analysis.summary}</p>
                  </div>
                </CardContent>
              </Card>

              {/* Asset Allocation */}
              <Card className="glass-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <DollarSign className="h-5 w-5 text-primary" />
                    Recommended Allocation
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {analysis.recommendations.map((rec, idx) => (
                      <div key={idx} className="p-4 rounded-lg bg-muted/30 space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="font-medium text-foreground">{rec.name}</span>
                          <span className="text-lg font-bold font-mono text-primary">{rec.allocation}%</span>
                        </div>
                        <div className="flex items-center gap-4 text-xs text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <Leaf className="h-3 w-3 text-sustainable" />
                            ESG: {rec.esgScore}
                          </span>
                          <span className="flex items-center gap-1">
                            <TrendingUp className="h-3 w-3 text-accentBlue" />
                            Return: {rec.expectedReturn}%
                          </span>
                        </div>
                        <div className="flex flex-wrap gap-1">
                          {rec.sdgAlignment.map((sdg, i) => (
                            <span key={i} className="px-2 py-0.5 rounded-full bg-primary/10 text-primary text-xs">
                              {sdg}
                            </span>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </>
          ) : (
            <div className="lg:col-span-2 glass-card flex items-center justify-center min-h-[400px]">
              <div className="text-center space-y-4">
                <TrendingUp className="h-16 w-16 text-muted-foreground/30 mx-auto" />
                <div>
                  <h3 className="text-lg font-medium text-foreground">No Portfolio Generated</h3>
                  <p className="text-sm text-muted-foreground">
                    Configure your preferences and click "Generate Portfolio" to get AI recommendations
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </DashboardLayout>
  );
}
