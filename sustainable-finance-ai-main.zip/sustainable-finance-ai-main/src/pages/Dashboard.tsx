import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { MetricCard } from '@/components/dashboard/MetricCard';
import { AgentCard } from '@/components/dashboard/AgentCard';
import { SDGWheel } from '@/components/dashboard/SDGWheel';
import { ScoreGauge } from '@/components/dashboard/ScoreGauge';
import { Shield, TrendingUp, Users, Leaf, DollarSign, Target, Globe } from 'lucide-react';

const sdgData = [
  { goal: 1, name: 'No Poverty', score: 72 },
  { goal: 2, name: 'Zero Hunger', score: 45 },
  { goal: 3, name: 'Good Health', score: 68 },
  { goal: 4, name: 'Quality Education', score: 55 },
  { goal: 5, name: 'Gender Equality', score: 78 },
  { goal: 6, name: 'Clean Water', score: 62 },
  { goal: 7, name: 'Affordable Energy', score: 85 },
  { goal: 8, name: 'Decent Work', score: 70 },
  { goal: 9, name: 'Industry Innovation', score: 88 },
  { goal: 10, name: 'Reduced Inequalities', score: 65 },
  { goal: 11, name: 'Sustainable Cities', score: 58 },
  { goal: 12, name: 'Responsible Consumption', score: 52 },
  { goal: 13, name: 'Climate Action', score: 92 },
  { goal: 14, name: 'Life Below Water', score: 40 },
  { goal: 15, name: 'Life on Land', score: 48 },
  { goal: 16, name: 'Peace & Justice', score: 60 },
  { goal: 17, name: 'Partnerships', score: 75 },
];

export default function Dashboard() {
  const { user, loading } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!loading && !user) {
      navigate('/auth');
    }
  }, [user, loading, navigate]);

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-pulse text-muted-foreground">Loading...</div>
      </div>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6 animate-fade-in">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Dashboard</h1>
            <p className="text-muted-foreground mt-1">
              Multi-Agent Sustainable Finance Intelligence Platform
            </p>
          </div>
          <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-sustainable/10 border border-sustainable/20">
            <div className="h-2 w-2 rounded-full bg-sustainable animate-pulse" />
            <span className="text-sm font-medium text-sustainable">All Agents Active</span>
          </div>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <MetricCard
            title="Total Portfolio Value"
            value="$12.4M"
            change={8.3}
            changeLabel="vs last month"
            icon={<DollarSign className="h-5 w-5 text-primary" />}
            variant="success"
          />
          <MetricCard
            title="Sustainability Score"
            value="78/100"
            change={5.2}
            changeLabel="improvement"
            icon={<Leaf className="h-5 w-5 text-sustainable" />}
            variant="success"
          />
          <MetricCard
            title="Risk Assessments"
            value="142"
            change={12}
            changeLabel="this week"
            icon={<Shield className="h-5 w-5 text-accentBlue" />}
          />
          <MetricCard
            title="Inclusion Score"
            value="85%"
            change={3.1}
            changeLabel="reach expanded"
            icon={<Users className="h-5 w-5 text-inclusion-teal" />}
            variant="success"
          />
        </div>

        {/* AI Agents Section */}
        <div>
          <h2 className="text-xl font-semibold text-foreground mb-4">AI Agents</h2>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <AgentCard
              title="Credit & Risk Intelligence"
              description="Dynamic sustainability-aware credit scoring and risk assessment powered by ESG data."
              icon={<Shield className="h-6 w-6" />}
              status="active"
              metrics={[
                { label: 'Assessments Today', value: '24' },
                { label: 'Avg Risk Score', value: '72' },
              ]}
              href="/credit-risk"
              gradient="sustainable"
            />
            <AgentCard
              title="Portfolio Advisory"
              description="AI-powered investment optimization balancing returns with sustainability impact."
              icon={<TrendingUp className="h-6 w-6" />}
              status="active"
              metrics={[
                { label: 'Portfolios Managed', value: '18' },
                { label: 'Green Allocation', value: '64%' },
              ]}
              href="/portfolio"
              gradient="accent"
            />
            <AgentCard
              title="Financial Inclusion"
              description="Micro-credit scoring and personalized financial products for underserved communities."
              icon={<Users className="h-6 w-6" />}
              status="processing"
              metrics={[
                { label: 'Applications', value: '89' },
                { label: 'Approval Rate', value: '78%' },
              ]}
              href="/inclusion"
              gradient="inclusion"
            />
          </div>
        </div>

        {/* SDG Alignment & Scores */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 glass-card p-6">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="text-lg font-semibold text-foreground">SDG Alignment</h3>
                <p className="text-sm text-muted-foreground">Portfolio contribution to UN Sustainable Development Goals</p>
              </div>
              <Globe className="h-5 w-5 text-muted-foreground" />
            </div>
            <div className="flex items-center justify-center">
              <SDGWheel data={sdgData} size={300} />
            </div>
          </div>
          
          <div className="glass-card p-6">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="text-lg font-semibold text-foreground">Performance Scores</h3>
                <p className="text-sm text-muted-foreground">Key sustainability metrics</p>
              </div>
              <Target className="h-5 w-5 text-muted-foreground" />
            </div>
            <div className="space-y-6">
              <div className="flex justify-around">
                <ScoreGauge value={78} label="ESG Score" variant="sustainable" size="sm" />
                <ScoreGauge value={65} label="Climate Risk" variant="risk" size="sm" />
              </div>
              <div className="flex justify-around">
                <ScoreGauge value={82} label="Governance" variant="neutral" size="sm" />
                <ScoreGauge value={71} label="Social Impact" variant="sustainable" size="sm" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
