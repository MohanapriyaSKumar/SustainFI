import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useEffect } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ScoreGauge } from '@/components/dashboard/ScoreGauge';
import { useToast } from '@/hooks/use-toast';
import { Shield, Sparkles, AlertTriangle, CheckCircle, TrendingDown, Loader2 } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';

interface RiskAssessment {
  financialScore: number;
  sustainabilityScore: number;
  overallRisk: 'low' | 'medium' | 'high' | 'critical';
  climateRiskExposure: number;
  governanceScore: number;
  socialScore: number;
  summary: string;
  recommendations: string[];
}

export default function CreditRisk() {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const [entityName, setEntityName] = useState('');
  const [entityType, setEntityType] = useState('');
  const [financialData, setFinancialData] = useState('');
  const [analyzing, setAnalyzing] = useState(false);
  const [assessment, setAssessment] = useState<RiskAssessment | null>(null);

  useEffect(() => {
    if (!loading && !user) {
      navigate('/auth');
    }
  }, [user, loading, navigate]);

  const handleAnalyze = async () => {
    if (!entityName || !entityType) {
      toast({
        title: 'Missing Information',
        description: 'Please provide entity name and type.',
        variant: 'destructive',
      });
      return;
    }

    setAnalyzing(true);
    
    try {
      const { data, error } = await supabase.functions.invoke('analyze-credit-risk', {
        body: {
          entityName,
          entityType,
          financialData,
        },
      });

      if (error) throw error;

      setAssessment(data.assessment);
      
      // Save to database
      await supabase.from('risk_assessments').insert({
        user_id: user?.id,
        entity_name: entityName,
        entity_type: entityType,
        financial_score: data.assessment.financialScore,
        sustainability_score: data.assessment.sustainabilityScore,
        overall_risk: data.assessment.overallRisk,
        climate_risk_exposure: data.assessment.climateRiskExposure,
        governance_score: data.assessment.governanceScore,
        social_score: data.assessment.socialScore,
        analysis_summary: data.assessment.summary,
        recommendations: data.assessment.recommendations,
      });

      toast({
        title: 'Analysis Complete',
        description: 'Credit and sustainability assessment generated successfully.',
      });
    } catch (error) {
      console.error('Analysis error:', error);
      toast({
        title: 'Analysis Failed',
        description: 'Unable to complete the risk assessment. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setAnalyzing(false);
    }
  };

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case 'low': return 'text-sustainable';
      case 'medium': return 'text-risk-amber';
      case 'high': return 'text-risk-red';
      case 'critical': return 'text-destructive';
      default: return 'text-muted-foreground';
    }
  };

  const getRiskIcon = (risk: string) => {
    switch (risk) {
      case 'low': return <CheckCircle className="h-5 w-5 text-sustainable" />;
      case 'medium': return <AlertTriangle className="h-5 w-5 text-risk-amber" />;
      case 'high': return <TrendingDown className="h-5 w-5 text-risk-red" />;
      case 'critical': return <AlertTriangle className="h-5 w-5 text-destructive" />;
      default: return null;
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-pulse text-muted-foreground">Loading...</div>
      </div>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6 animate-fade-in">
        {/* Header */}
        <div className="flex items-center gap-4">
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-sustainable/20">
            <Shield className="h-6 w-6 text-sustainable" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-foreground">Credit & Risk Intelligence</h1>
            <p className="text-muted-foreground">
              AI-powered sustainability-aware credit and risk assessment
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Input Form */}
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Sparkles className="h-5 w-5 text-primary" />
                New Assessment
              </CardTitle>
              <CardDescription>
                Enter entity details for comprehensive risk analysis
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="entityName">Entity Name</Label>
                <Input
                  id="entityName"
                  placeholder="e.g., GreenTech Solutions Inc."
                  value={entityName}
                  onChange={(e) => setEntityName(e.target.value)}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="entityType">Entity Type</Label>
                <Select value={entityType} onValueChange={setEntityType}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select entity type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="corporation">Corporation</SelectItem>
                    <SelectItem value="sme">SME</SelectItem>
                    <SelectItem value="startup">Startup</SelectItem>
                    <SelectItem value="nonprofit">Non-Profit</SelectItem>
                    <SelectItem value="government">Government Entity</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="financialData">Financial & ESG Context (Optional)</Label>
                <Textarea
                  id="financialData"
                  placeholder="Provide any relevant financial metrics, sustainability initiatives, industry sector, or other context..."
                  value={financialData}
                  onChange={(e) => setFinancialData(e.target.value)}
                  rows={4}
                />
              </div>
              
              <Button 
                className="w-full" 
                onClick={handleAnalyze}
                disabled={analyzing}
              >
                {analyzing ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Analyzing...
                  </>
                ) : (
                  <>
                    <Sparkles className="mr-2 h-4 w-4" />
                    Generate Assessment
                  </>
                )}
              </Button>
            </CardContent>
          </Card>

          {/* Results */}
          {assessment && (
            <Card className="glass-card">
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>Assessment Results</span>
                  <div className="flex items-center gap-2">
                    {getRiskIcon(assessment.overallRisk)}
                    <span className={`text-sm font-medium uppercase ${getRiskColor(assessment.overallRisk)}`}>
                      {assessment.overallRisk} Risk
                    </span>
                  </div>
                </CardTitle>
                <CardDescription>{entityName}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Scores */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="flex flex-col items-center">
                    <ScoreGauge 
                      value={assessment.financialScore} 
                      label="Financial Score" 
                      variant="neutral"
                      size="sm"
                    />
                  </div>
                  <div className="flex flex-col items-center">
                    <ScoreGauge 
                      value={assessment.sustainabilityScore} 
                      label="Sustainability Score" 
                      variant="sustainable"
                      size="sm"
                    />
                  </div>
                </div>

                {/* ESG Breakdown */}
                <div className="space-y-3">
                  <h4 className="text-sm font-medium text-foreground">ESG Breakdown</h4>
                  <div className="grid grid-cols-3 gap-4">
                    <div className="text-center p-3 rounded-lg bg-muted/50">
                      <p className="text-2xl font-bold font-mono text-foreground">{assessment.climateRiskExposure}</p>
                      <p className="text-xs text-muted-foreground">Climate Risk</p>
                    </div>
                    <div className="text-center p-3 rounded-lg bg-muted/50">
                      <p className="text-2xl font-bold font-mono text-foreground">{assessment.socialScore}</p>
                      <p className="text-xs text-muted-foreground">Social</p>
                    </div>
                    <div className="text-center p-3 rounded-lg bg-muted/50">
                      <p className="text-2xl font-bold font-mono text-foreground">{assessment.governanceScore}</p>
                      <p className="text-xs text-muted-foreground">Governance</p>
                    </div>
                  </div>
                </div>

                {/* Summary */}
                <div className="space-y-2">
                  <h4 className="text-sm font-medium text-foreground">Analysis Summary</h4>
                  <p className="text-sm text-muted-foreground">{assessment.summary}</p>
                </div>

                {/* Recommendations */}
                <div className="space-y-2">
                  <h4 className="text-sm font-medium text-foreground">Recommendations</h4>
                  <ul className="space-y-2">
                    {assessment.recommendations.map((rec, idx) => (
                      <li key={idx} className="flex items-start gap-2 text-sm text-muted-foreground">
                        <CheckCircle className="h-4 w-4 text-sustainable mt-0.5 flex-shrink-0" />
                        {rec}
                      </li>
                    ))}
                  </ul>
                </div>
              </CardContent>
            </Card>
          )}

          {!assessment && (
            <div className="glass-card flex items-center justify-center min-h-[400px]">
              <div className="text-center space-y-4">
                <Shield className="h-16 w-16 text-muted-foreground/30 mx-auto" />
                <div>
                  <h3 className="text-lg font-medium text-foreground">No Assessment Yet</h3>
                  <p className="text-sm text-muted-foreground">
                    Fill in the form and click "Generate Assessment" to get started
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </DashboardLayout>
  );
}
