import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Activity, Shield, TrendingUp, Users, Clock, Zap } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { format } from 'date-fns';

interface AgentActivity {
  id: string;
  agent_type: 'credit_risk' | 'portfolio_advisory' | 'financial_inclusion';
  action: string;
  input_summary: string | null;
  output_summary: string | null;
  confidence_score: number | null;
  processing_time_ms: number | null;
  created_at: string;
}

export default function ActivityPage() {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const [activities, setActivities] = useState<AgentActivity[]>([]);
  const [loadingData, setLoadingData] = useState(true);

  useEffect(() => {
    if (!loading && !user) {
      navigate('/auth');
    }
  }, [user, loading, navigate]);

  useEffect(() => {
    if (user) {
      fetchActivities();
    }
  }, [user]);

  const fetchActivities = async () => {
    const { data, error } = await supabase
      .from('agent_activities')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(50);

    if (!error && data) {
      setActivities(data as AgentActivity[]);
    }
    setLoadingData(false);
  };

  const getAgentIcon = (type: string) => {
    switch (type) {
      case 'credit_risk': return <Shield className="h-4 w-4" />;
      case 'portfolio_advisory': return <TrendingUp className="h-4 w-4" />;
      case 'financial_inclusion': return <Users className="h-4 w-4" />;
      default: return <Activity className="h-4 w-4" />;
    }
  };

  const getAgentColor = (type: string) => {
    switch (type) {
      case 'credit_risk': return 'bg-sustainable/20 text-sustainable border-sustainable/30';
      case 'portfolio_advisory': return 'bg-accentBlue/20 text-accentBlue border-accentBlue/30';
      case 'financial_inclusion': return 'bg-inclusion-teal/20 text-inclusion-teal border-inclusion-teal/30';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const getAgentName = (type: string) => {
    switch (type) {
      case 'credit_risk': return 'Credit & Risk';
      case 'portfolio_advisory': return 'Portfolio Advisory';
      case 'financial_inclusion': return 'Financial Inclusion';
      default: return type;
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-pulse text-muted-foreground">Loading...</div>
      </div>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6 animate-fade-in">
        {/* Header */}
        <div className="flex items-center gap-4">
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-sdg-purple/20">
            <Activity className="h-6 w-6 text-sdg-purple" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-foreground">Agent Activity</h1>
            <p className="text-muted-foreground">
              Real-time transparency into AI agent operations
            </p>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card className="glass-card">
            <CardContent className="pt-6">
              <div className="flex items-center gap-4">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-sustainable/20">
                  <Shield className="h-5 w-5 text-sustainable" />
                </div>
                <div>
                  <p className="text-2xl font-bold font-mono text-foreground">
                    {activities.filter(a => a.agent_type === 'credit_risk').length}
                  </p>
                  <p className="text-sm text-muted-foreground">Credit Assessments</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="glass-card">
            <CardContent className="pt-6">
              <div className="flex items-center gap-4">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-accentBlue/20">
                  <TrendingUp className="h-5 w-5 text-accentBlue" />
                </div>
                <div>
                  <p className="text-2xl font-bold font-mono text-foreground">
                    {activities.filter(a => a.agent_type === 'portfolio_advisory').length}
                  </p>
                  <p className="text-sm text-muted-foreground">Portfolio Optimizations</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="glass-card">
            <CardContent className="pt-6">
              <div className="flex items-center gap-4">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-inclusion-teal/20">
                  <Users className="h-5 w-5 text-inclusion-teal" />
                </div>
                <div>
                  <p className="text-2xl font-bold font-mono text-foreground">
                    {activities.filter(a => a.agent_type === 'financial_inclusion').length}
                  </p>
                  <p className="text-sm text-muted-foreground">Inclusion Profiles</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Activity Log */}
        <Card className="glass-card">
          <CardHeader>
            <CardTitle>Activity Log</CardTitle>
            <CardDescription>
              Complete audit trail of all AI agent operations
            </CardDescription>
          </CardHeader>
          <CardContent>
            {loadingData ? (
              <div className="text-center py-8 text-muted-foreground">
                Loading activities...
              </div>
            ) : activities.length === 0 ? (
              <div className="text-center py-12 space-y-4">
                <Activity className="h-16 w-16 text-muted-foreground/30 mx-auto" />
                <div>
                  <h3 className="text-lg font-medium text-foreground">No Activity Yet</h3>
                  <p className="text-sm text-muted-foreground">
                    Start using the AI agents to see activity logs here
                  </p>
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                {activities.map((activity) => (
                  <div
                    key={activity.id}
                    className="flex items-start gap-4 p-4 rounded-lg bg-muted/30 hover:bg-muted/50 transition-colors"
                  >
                    <div className={`flex h-10 w-10 items-center justify-center rounded-lg ${getAgentColor(activity.agent_type)}`}>
                      {getAgentIcon(activity.agent_type)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <Badge variant="outline" className={getAgentColor(activity.agent_type)}>
                          {getAgentName(activity.agent_type)}
                        </Badge>
                        <span className="text-sm font-medium text-foreground">{activity.action}</span>
                      </div>
                      {activity.input_summary && (
                        <p className="text-sm text-muted-foreground truncate">{activity.input_summary}</p>
                      )}
                      <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          {format(new Date(activity.created_at), 'MMM d, yyyy HH:mm')}
                        </span>
                        {activity.processing_time_ms && (
                          <span className="flex items-center gap-1">
                            <Zap className="h-3 w-3" />
                            {activity.processing_time_ms}ms
                          </span>
                        )}
                        {activity.confidence_score && (
                          <span className="flex items-center gap-1">
                            Confidence: {activity.confidence_score}%
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
